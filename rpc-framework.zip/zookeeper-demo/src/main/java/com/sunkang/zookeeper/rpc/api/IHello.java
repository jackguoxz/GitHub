package com.sunkang.zookeeper.rpc.api;

/**
 * @Project: 3.DistributedProject
 * @description:  iHello接口
 * @author: sunkang
 * @create: 2018-06-23 11:30
 * @ModificationHistory who      when       What
 **/
public interface IHello {
    String sayHello(String msg);

}
