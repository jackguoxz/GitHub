package com.sunkang.zookeeper.rpc.client.discovery;

/**
 * @Project: 3.DistributedProject
 * @description:
 * @author: sunkang
 * @create: 2018-06-24 13:31
 * @ModificationHistory who      when       What
 **/
public interface iServiceDiscovery {

     String discovery(String serviceName);
}
