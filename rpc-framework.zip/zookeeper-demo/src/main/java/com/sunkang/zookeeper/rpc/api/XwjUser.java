package com.sunkang.zookeeper.rpc.api;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.Serializable;
import java.util.Date;
import java.util.List;


public class XwjUser implements Serializable {

    public static ObjectMapper mapper = new ObjectMapper();

    static {
        // 转换为格式化的json««
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        // 如果json中有新增的字段并且是实体类类中不存在的，不报错
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public static void main(String []args)
    {
        XwjUser user = new XwjUser(1, "Hello World", new Date());

        //mapper.writeValue(new File("D:/test.txt"), user); // 写到文件中
        // mapper.writeValue(System.out, user); //写到控制台
        try {
            String jsonStr = mapper.writeValueAsString(user);
            System.out.println("对象转为字符串：" + jsonStr);

            byte[] byteArr = mapper.writeValueAsBytes(user);
            System.out.println("对象转为byte数组：" + byteArr);

            XwjUser userDe = mapper.readValue(jsonStr, XwjUser.class);
            System.out.println("json字符串转为对象：" + userDe);

            XwjUser useDe2 = mapper.readValue(byteArr, XwjUser.class);
            System.out.println("byte数组转为对象：" + useDe2);
        }catch (Exception e)
        {

        }
    }
    private static final long serialVersionUID = 1L;

    private int id;

    private String message;

    private Date sendTime;

    // 这里手写字母大写，只是为了测试使用，是不符合java规范的
    private String NodeName;

    private List<Integer> intList;

    public XwjUser() {
        super();
    }

    public XwjUser(int id, String message, Date sendTime) {
        super();
        this.id = id;
        this.message = message;
        this.sendTime = sendTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

    public String getNodeName() {
        return NodeName;
    }

    public void setNodeName(String nodeName) {
        NodeName = nodeName;
    }

    public List<Integer> getIntList() {
        return intList;
    }

    public void setIntList(List<Integer> intList) {
        this.intList = intList;
    }

    @Override
    public String toString() {
        return "XwjUser [id=" + id + ", message=" + message + ", sendTime=" + sendTime + ", intList=" + intList + "]";
    }

}
